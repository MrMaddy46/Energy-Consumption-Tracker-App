// script.js

// Configuration
const API_ENDPOINT = 'https://api.energytracker.com/data';
const POLL_INTERVAL = 60000; // 1 minute

// DOM Elements
const energyUsageElement = document.getElementById('currentUsage');
const errorElement = document.getElementById('error');
const chartCanvas = document.getElementById('energyChart').getContext('2d');

// Chart instance (using Chart.js)
let energyChart;

// Fetch energy data from IoT API
async function fetchEnergyData() {
    try {
        const response = await fetch(API_ENDPOINT);
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        updateUI(data);
    } catch (error) {
        handleError(error);
    }
}

// Update UI with new data
function updateUI(data) {
    // Update current usage
    energyUsageElement.textContent = `Current Usage: ${data.currentUsage.toFixed(2)} kWh`;
    
    // Update chart
    if (!energyChart) {
        energyChart = new Chart(chartCanvas, {
            type: 'line',
            data: {
                labels: data.history.map(entry => entry.timestamp),
                datasets: [{
                    label: 'Energy Usage (kWh)',
                    data: data.history.map(entry => entry.usage),
                    borderColor: '#4CAF50',
                    tension: 0.1
                }]
            }
        });
    } else {
        energyChart.data.labels = data.history.map(entry => entry.timestamp);
        energyChart.data.datasets[0].data = data.history.map(entry => entry.usage);
        energyChart.update();
    }
}

// Error handling
function handleError(error) {
    console.error('Error:', error);
    errorElement.textContent = `Error: ${error.message}`;
    errorElement.style.display = 'block';
    setTimeout(() => errorElement.style.display = 'none', 5000); // Hide after 5s
}

// Initialize app
function init() {
    fetchEnergyData();
    setInterval(fetchEnergyData, POLL_INTERVAL);
}

// Start app when DOM is ready
document.addEventListener('DOMContentLoaded', init);
