# Energy Consumption Tracker

## Overview
The Energy Consumption Tracker is a web application that allows users to monitor and optimize their energy usage. Users can log in, register, and track their energy consumption data in real-time.

## Project Structure